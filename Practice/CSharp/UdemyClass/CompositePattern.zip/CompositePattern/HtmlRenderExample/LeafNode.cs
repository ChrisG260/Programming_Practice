using System;

namespace HtmlRenderExample
{
	/// <summary>
	/// The leaf abstract base class.
	/// </summary>
	public abstract class LeafNode : HtmlNode
	{
	}
	
}
