using System;

namespace FactoryMethodPattern
{
	/// <summary>
	/// The concrete product B.
	/// </summary>
	class ConcreteProductB : Product
	{
	}
}
