using System;

namespace FactoryMethodPattern
{
	/// <summary>
	/// The abstract product class.
	/// </summary>
	abstract class Product
	{
	}
}
