using System;

namespace FactoryMethodPattern
{
	/// <summary>
	/// The concrete product A.
	/// </summary>
	class ConcreteProductA : Product
	{
	}
}
