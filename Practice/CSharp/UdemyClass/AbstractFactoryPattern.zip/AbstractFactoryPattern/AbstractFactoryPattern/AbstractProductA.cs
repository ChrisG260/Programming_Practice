using System;

namespace AbstractFactoryPattern
{
	/// <summary>
	/// The abstract product class for product A.
	/// </summary>
	abstract class AbstractProductA
	{
	}
}
