using System;

namespace FoodchainExample
{
	/// <summary>
	/// The concrete product class for herbivores in Africa.
	/// </summary>
	class Zebra : Herbivore
	{
	}
}
