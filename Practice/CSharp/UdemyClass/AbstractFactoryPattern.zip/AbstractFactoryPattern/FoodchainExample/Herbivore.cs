using System;

namespace FoodchainExample
{
	/// <summary>
	/// The abstract product class for herbivores.
	/// </summary>
	abstract class Herbivore
	{
	}
}
